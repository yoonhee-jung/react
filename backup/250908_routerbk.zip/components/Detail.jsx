function Detail() {
  return (
    <>
    <h3>상세 페이지..</h3>
    </>
  )
}


export default Detail