function NotFound() {
  return (
    <>
    <h3 style={{color: 'red'}}>Not Found</h3>
    
    </>


  )
}

export default NotFound