function List() {
  return (

    <>
    <h2>리스트 ..</h2>
    </>

  )
}

export default List